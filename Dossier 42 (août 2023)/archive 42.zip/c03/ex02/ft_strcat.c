/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: flacroix <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/16 23:04:26 by flacroix          #+#    #+#             */
/*   Updated: 2023/08/21 20:53:58 by flacroix         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	i1;

	i = 0;
	i1 = 0;
	while (dest[i] != '\0')
	{
		i++;
	}
	while (src[i1] != '\0')
	{
		dest[i] = src[i1];
		i1++;
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

/*
int	main(void)
{
	char	a[20] = "tessssttt";
	char	b[20] = "united";
	printf("%s\n", ft_strcat(a, b));
}
*/
