/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glecardo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/12 15:26:22 by glecardo          #+#    #+#             */
/*   Updated: 2023/08/12 15:53:50 by glecardo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	debut(int x)
{
	int	c;

	c = 2;
	ft_putchar('A');
	if (x > 1)
	{
		while (x > c)
		{
			ft_putchar('B');
			c++;
		}
		ft_putchar('C');
	}
	ft_putchar('\n');
}

void	millieu(int x)
{
	int	d;

	d = 3;
	ft_putchar('B');
	while (x >= d)
	{
		ft_putchar(' ');
		d++;
	}
	if (x > 1)
	{
		ft_putchar('B');
	}
	ft_putchar('\n');
}

void	rush(int x, int y)
{
	int	f;

	f = 1;
	if (x > 0 && y > 0)
	{
		debut(x);
	}
	if (y > 1 && x > 0)
	{
		while (y - 2 >= f)
		{
			millieu(x);
			f++;
		}
		debut(x);
	}
}
