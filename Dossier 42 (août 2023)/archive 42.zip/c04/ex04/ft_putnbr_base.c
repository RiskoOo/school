/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: flacroix <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/28 08:55:04 by flacroix          #+#    #+#             */
/*   Updated: 2023/08/29 01:35:10 by flacroix         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>
#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	verif_base(char *base)
{
	int	i;
	int	j;
	int	size;

	i = -1;
	size = ft_strlen(base);
	if (size == 0 || size == 1)
		return (0);
	while (i++ < size)
	{
		j = i + 1;
		while (j < size)
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
	}
	while (*base)
	{
		if (*base == '-' || *base == '+')
			return (0);
		base++;
	}
	return (1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	div;
	int	mod;

	if (!(verif_base(base)))
		return ;
	if (nbr < 0)
		ft_putchar('-');
	if (nbr / ft_strlen(base) != 0)
	{
		div = nbr / ft_strlen(base); 
		if (div < 0)
			div = -div;
		ft_putnbr_base(div, base);
		mod = nbr % ft_strlen(base);
		if (mod < 0)
			mod = -mod;
		ft_putnbr_base(mod, base);
	}
	else
	{
		if (nbr < 0)
			nbr = -nbr;
		ft_putchar(base[nbr]);
	}
}

/*
int	main(void)
{
	int nb = 11;
	char base[] = "0123456789abcdef";

	ft_putnbr_base(nb, base);
}
*/
