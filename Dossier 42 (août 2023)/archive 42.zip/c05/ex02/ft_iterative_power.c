/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: flacroix <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/31 14:11:56 by flacroix          #+#    #+#             */
/*   Updated: 2023/08/31 17:50:10 by flacroix         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

int	ft_iterative_power(int nb, int power)
{
	int				i;
	unsigned int	result;

	i = 1;
	result = nb;
	if (nb < 0)
		return (0);
	if (power < 0)
		return (0);
	if (power == 0 || nb == 0)
		return (1);
	while (i < power)
	{
		nb *= result;
		i++;
	}
	return (nb);
}

/*
int	main(void)
{
	int nb = 0;
	int power = 4;

	printf("%d\n", ft_iterative_power(nb, power));
}
*/
