/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: flacroix <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/13 18:18:24 by flacroix          #+#    #+#             */
/*   Updated: 2023/08/13 20:52:12 by flacroix         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
#include <unistd.h>
#include <stdio.h>
*/

void	ft_swap(int *a, int *b)
{
	int	swap;

	swap = *a;
	*a = *b;
	*b = swap;
}

/*
void	main(void)
{
	int	a;
	int	b;
	a = 3;
	b = 6;
	printf("a: %d", a);
	printf(", b: %d\n", b);
	ft_swap(&a, &b);
	printf("a: %d", a);
	printf(", b: %d\n", b);
}
*/
