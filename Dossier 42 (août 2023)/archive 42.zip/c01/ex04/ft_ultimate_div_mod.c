/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: flacroix <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/13 21:55:57 by flacroix          #+#    #+#             */
/*   Updated: 2023/08/14 11:17:28 by flacroix         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
#include <stdio.h>
*/

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	tmp;

	tmp = *a;
	*a = *a / *b;
	*b = tmp % *b;
}

/*
void	main(void)
{
	int	a;
	int	b;
	a = 4;
	b = 2;
	printf("a : %d", a);
	printf(", b : %d", b);
	ft_ultimate_div_mod(&a, &b);
	printf(", A : %d", a);
	printf(", B : %d", b);
}
*/
